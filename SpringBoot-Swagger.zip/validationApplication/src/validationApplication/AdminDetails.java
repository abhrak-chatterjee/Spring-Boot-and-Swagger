package validationApplication;

import java.util.ArrayList;
import java.util.Iterator;

public class AdminDetails {
       
       
       public String n;
       public String p;
       public String t;
       public AdminDetails()
       {
              
       }
       public AdminDetails(String n,String p,String t)
       {
              this.n=n;
              this.p=p;
              this.t=t;
       }
       public String getN() {
              return n;
       }
       public void setN(String n) {
              this.n = n;
       }
       public String getP() {
              return p;
       }
       public void setP(String p) {
              this.p = p;
       }
       
       
       @Override
       public String toString() {
              return "AdminDetails [getN()=" + getN() + ", getP()=" + getP() + "]";
       }
       
       

       

}
