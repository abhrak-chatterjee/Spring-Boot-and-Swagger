package validationApplication;
import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.lang.String;
import java.sql.*;
import java.util.*;
 import javax.servlet.*;

class OracleCon extends HttpServlet
{  
	public void procesRequest(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{  
		
		List<String> userName=new ArrayList<String>();
		List<String> password=new ArrayList<String>();
		try
		{
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","abhrak","abhrak");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select * from users");  
			while(rs.next()) 
			{
				userName.add(rs.getString(1));
				password.add(rs.getString(2));
			}
			  
			  
			//step5 close the connection object  
			con.close();  
			  
		}
		catch(Exception e)
		{ 
			System.out.println(e);
		}  
	}  
}  
