package com.capgemini.classes;

public class Employee 
{
	int empId;
	String empName;
	double empSalary;
	/*public Employee()
	{
		System.out.println("Default Constructor");
	}
	public Employee(int empId,String empName,double empSalary)
	{
		System.out.println("Parameterized Constructor");
		this.empId=empId;
		this.empName=empName;
		this.empSalary=empSalary;
	}*/
	public void setEmpId(int empId) 
	{
		this.empId = empId;
	}
	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}
	public void setEmpSalary(double empSalary) 
	{
		this.empSalary = empSalary;
	}
	@Override
	public String toString() 
	{
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}
}
