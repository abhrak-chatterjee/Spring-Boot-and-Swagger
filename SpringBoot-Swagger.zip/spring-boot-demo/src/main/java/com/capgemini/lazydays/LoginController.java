package com.capgemini.lazydays;

import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class LoginController 
{
    @RequestMapping("/home")
    public ModelAndView home(Map<String, Object> model)
    {
		ModelAndView mav= new ModelAndView ("home");
		return mav;
	}

//    @RequestMapping(value = "/login")
//   
//    public String submit(@Valid @ModelAttribute("userForm") LoginBean userForm,
//            BindingResult result, Map<String, Object> model) {
// 
//        if (result.hasErrors()) {
//            return "login";
//        }
// 
//        return "success";
    
}
